const { 
  supabase, 
  corsHeaders
} = require('./utils');

exports.handler = async (event, context) => {
  const origin = event.headers.origin || event.headers.Origin;
  
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders(origin),
      body: ''
    };
  }

  // Only allow POST method for validation
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { inviteCode } = JSON.parse(event.body);

    if (!inviteCode) {
      return {
        statusCode: 400,
        headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Invite code is required' })
      };
    }    // Check if invite code exists and is valid
    const { data: invite, error } = await supabase
      .from('invites')
      .select('id, code, redeemed, expires_at, created_at')
      .eq('code', inviteCode)
      .single();

    if (error || !invite) {
      return {
        statusCode: 200,
        headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          valid: false, 
          message: 'Invalid invite code' 
        })
      };
    }

    // Check if invite is already redeemed
    if (invite.redeemed) {
      return {
        statusCode: 200,
        headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          valid: false, 
          message: 'Invite code has already been used' 
        })
      };
    }

    // Check if invite is expired
    const now = new Date();
    const expiresAt = new Date(invite.expires_at);
    
    if (now > expiresAt) {
      return {
        statusCode: 200,
        headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          valid: false, 
          message: 'Invite code has expired' 
        })
      };
    }

    // Invite is valid - for now we'll skip the reservation system until DB is updated
    return {
      statusCode: 200,
      headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        valid: true, 
        message: 'Invite code is valid. Complete your registration.',
        inviteId: invite.id // Pass invite ID for validation in signup
      })
    };

  } catch (error) {
    console.error('Invite validation error:', error);
    return {
      statusCode: 500,
      headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        valid: false, 
        error: 'Internal server error', 
        details: error.message 
      })
    };
  }
};
